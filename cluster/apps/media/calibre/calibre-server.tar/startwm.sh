#!/bin/bash
/usr/bin/pulseaudio --start
/usr/bin/openbox-session > /dev/null 2>&1
